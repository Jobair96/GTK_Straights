#include "Computer.h"

using namespace std;

Computer::Computer(const Deck &deck, const int playerNumber) : Player(deck, playerNumber) {

}
