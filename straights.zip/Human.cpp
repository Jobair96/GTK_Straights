#include "Human.h"

using namespace std;

Human::Human(const Deck &deck, const int playerNumber) : Player(deck, playerNumber) {
	
}
